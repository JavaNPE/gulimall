package com.atguigu.gulimall.member.dao;

import com.atguigu.gulimall.member.entity.UndoLogEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 
 * 
 * @author ÍõÈ½ê¿
 * @email daki9981@qq.com
 * @date 2021-08-14 12:38:15
 */
@Mapper
public interface UndoLogDao extends BaseMapper<UndoLogEntity> {
	
}
